# BhishiBook

Independent Marathi bhishi management Android app.

## Free GitHub APK build

1. Create a free GitHub repository.
2. Upload all files from this project to the repository.
3. Open the **Actions** tab.
4. Select **Build BhishiBook APK** and run the workflow (or push to `main`).
5. When the workflow finishes, open the run and download the **BhishiBook-debug-apk** artifact.
6. Extract the ZIP and install `app-debug.apk` on Android.

No paid app subscription is bypassed. This is an independently implemented app.
